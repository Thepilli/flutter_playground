# fortune_wheel

A fortune wheel to make entertaining random decisions based on a given list.

![The fortune wheel in action](https://www.flutterclutter.dev/wp-content/uploads/2021/03/fortune-wheel-animate-small-2.gif)

# Article

Find the respective tutorial about how everything was created and how it's to be used on https://www.flutterclutter.dev/flutter/tutorials/implementing-a-fortune-wheel/2021/2223/